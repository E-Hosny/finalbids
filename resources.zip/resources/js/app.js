import './bootstrap';
import 'laravel-datatables-vite';
import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
